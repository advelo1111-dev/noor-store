# NOOR — Zero-budget storefront starter

This is a beginner-friendly **static storefront demo** built with HTML, CSS and JavaScript. It includes responsive design, product cards, category filters, search, a cart saved in the browser, and a Cash on Delivery order message that can be sent to WhatsApp.

## Run it on your computer
1. Extract the ZIP.
2. Open `index.html` in Chrome or Edge. No build tools are required.
3. To test checkout, open `app.js` and replace:
   `const WHATSAPP_NUMBER = "923001234567";`
   with your own number in international format, digits only. For Pakistan, start with `92` and omit the leading `0`.
4. Edit the `PRODUCTS` list in `app.js` to add your own names, prices, categories and image URLs.

## Free deployment: GitHub Pages
1. Create a free account at https://github.com/
2. Create a new **public** repository, e.g. `my-online-store`.
3. Upload `index.html`, `style.css`, and `app.js` to the repository root.
4. Open the repository's **Settings → Pages**.
5. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
6. Wait a few minutes. GitHub will show your published URL in the Pages section.

Alternative: drag the folder into a static hosting service that supports manual deployments, or import the GitHub repository into Vercel.

## Important limitations — read before selling
- This is a **front-end starter demo**, not a complete Shopify replacement or production-ready commerce backend.
- Products are hard-coded in `app.js`. Cart contents are stored in that customer's browser.
- The order form opens WhatsApp with an order message. It does **not** create a central order record, calculate courier fees, or verify payments.
- There is no secure admin dashboard, inventory sync, customer accounts, order database, or payment gateway in this starter.
- Never put passwords, secret API keys, or private customer information in front-end JavaScript.
- Product photos currently use remote Unsplash URLs and need an internet connection. Replace them with images you have permission to use.
- For a real store with shared products/orders and a secure admin area, add a backend/database such as Supabase, server-side validation, admin authentication, privacy/return policies, and test it before accepting real orders.
- The newsletter form is a visual demo and does not collect emails.

## Currency and brand
- Change the brand name `NOOR` in `index.html` and the document title.
- Change currency in `app.js` if needed.
- Replace `hello@example.com` in the footer.
