// Starter storefront. Edit the PRODUCTS list and WHATSAPP_NUMBER before using.
const WHATSAPP_NUMBER = "923001234567"; // Replace with your WhatsApp number: country code + number, digits only.
const CURRENCY = "Rs. ";

const PRODUCTS = [
  {id:1,name:"Linen Everyday Tote",category:"Accessories",price:1850,tag:"BESTSELLER",description:"A light, roomy carry-all for everyday plans.",image:"https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&w=800&q=85"},
  {id:2,name:"Ceramic Form Vase",category:"Home",price:2400,tag:"JUST IN",description:"Sculptural simplicity for your favourite corner.",image:"https://images.unsplash.com/photo-1578500494198-246f612d3b3d?auto=format&fit=crop&w=800&q=85"},
  {id:3,name:"Daily Ritual Bottle",category:"Lifestyle",price:1650,tag:"EVERYDAY",description:"A clean, practical companion for busy days.",image:"https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&w=800&q=85"},
  {id:4,name:"Soft Touch Cushion",category:"Home",price:3200,tag:"CUSTOMER FAVOURITE",description:"An easy texture refresh for your living space.",image:"https://images.unsplash.com/photo-1584100936595-c0654b55a2e2?auto=format&fit=crop&w=800&q=85"},
  {id:5,name:"Minimal Card Holder",category:"Accessories",price:1250,tag:"SMALL DETAILS",description:"A compact home for the things you carry.",image:"https://images.unsplash.com/photo-1627123424574-724758594e93?auto=format&fit=crop&w=800&q=85"},
  {id:6,name:"Weekend Candle",category:"Lifestyle",price:1950,tag:"SLOW MOMENTS",description:"A warm accent for your end-of-day routine.",image:"https://images.unsplash.com/photo-1603006905003-be475563bc59?auto=format&fit=crop&w=800&q=85"},
  {id:7,name:"Natural Texture Tray",category:"Home",price:2150,tag:"THOUGHTFUL DESIGN",description:"Keep small essentials in one beautiful place.",image:"https://images.unsplash.com/photo-1603199506016-b9a594b593c0?auto=format&fit=crop&w=800&q=85"},
  {id:8,name:"Classic Everyday Pouch",category:"Accessories",price:1450,tag:"ON THE GO",description:"A simple organiser for daily essentials.",image:"https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=800&q=85"}
];

const $ = (selector) => document.querySelector(selector);
let activeCategory = "All";
let searchTerm = "";
let cart = JSON.parse(localStorage.getItem("noor-cart") || "[]");

function money(amount) {
  return CURRENCY + amount.toLocaleString("en-PK");
}
function saveCart() {
  localStorage.setItem("noor-cart", JSON.stringify(cart));
  renderCart();
}
function renderProducts() {
  const shown = PRODUCTS.filter(product =>
    (activeCategory === "All" || product.category === activeCategory) &&
    (product.name + " " + product.description + " " + product.category).toLowerCase().includes(searchTerm)
  );
  $("#productGrid").innerHTML = shown.length ? shown.map(product => `
    <article class="product-card">
      <div class="product-image">
        <img src="${product.image}" alt="${product.name}" loading="lazy">
        <span class="product-tag">${product.tag}</span>
        <button class="add-button" data-add="${product.id}" aria-label="Add ${product.name} to bag">+</button>
      </div>
      <div class="product-info">
        <div class="product-category">${product.category}</div>
        <div class="product-title-row"><span class="product-title">${product.name}</span><span class="product-price">${money(product.price)}</span></div>
        <p class="product-description">${product.description}</p>
      </div>
    </article>`).join("") : `<div class="empty-state">No products found. Try another search.</div>`;
}
function cartCount() { return cart.reduce((sum, item) => sum + item.qty, 0); }
function cartTotal() { return cart.reduce((sum, item) => sum + item.price * item.qty, 0); }
function renderCart() {
  $("#cartCount").textContent = cartCount();
  $("#drawerCount").textContent = `(${cartCount()})`;
  $("#subtotal").textContent = money(cartTotal());
  $("#cartItems").innerHTML = cart.length ? cart.map(item => `
    <div class="cart-line">
      <img src="${item.image}" alt="">
      <div><p class="cart-line-title">${item.name}</p><span class="cart-line-price">${money(item.price)}</span>
        <div class="quantity"><button data-qty="${item.id}" data-change="-1" aria-label="Decrease quantity">−</button><span>${item.qty}</span><button data-qty="${item.id}" data-change="1" aria-label="Increase quantity">+</button></div>
      </div>
      <button class="remove-button" data-remove="${item.id}">Remove</button>
    </div>`).join("") : `<div class="empty-state">Your bag is waiting for something lovely.</div>`;
  $("#checkoutButton").disabled = !cart.length;
}
function openCart() {
  $("#cartDrawer").classList.add("open");
  $("#overlay").classList.add("visible");
  $("#cartDrawer").setAttribute("aria-hidden", "false");
  document.body.classList.add("no-scroll");
}
function closeCart() {
  $("#cartDrawer").classList.remove("open");
  $("#overlay").classList.remove("visible");
  $("#cartDrawer").setAttribute("aria-hidden", "true");
  document.body.classList.remove("no-scroll");
}
function addToCart(id) {
  const product = PRODUCTS.find(item => item.id === Number(id));
  const existing = cart.find(item => item.id === product.id);
  if (existing) existing.qty += 1;
  else cart.push({...product, qty:1});
  saveCart();
}
$("#productGrid").addEventListener("click", event => {
  const add = event.target.closest("[data-add]");
  if (add) addToCart(add.dataset.add);
});
$("#cartItems").addEventListener("click", event => {
  const qty = event.target.closest("[data-qty]");
  const remove = event.target.closest("[data-remove]");
  if (qty) {
    const item = cart.find(row => row.id === Number(qty.dataset.qty));
    item.qty += Number(qty.dataset.change);
    if (item.qty <= 0) cart = cart.filter(row => row.id !== item.id);
    saveCart();
  }
  if (remove) {
    cart = cart.filter(row => row.id !== Number(remove.dataset.remove));
    saveCart();
  }
});
$("#filters").addEventListener("click", event => {
  const button = event.target.closest("[data-category]");
  if (!button) return;
  activeCategory = button.dataset.category;
  document.querySelectorAll(".filter").forEach(filter => filter.classList.toggle("active", filter === button));
  renderProducts();
});
$("#searchInput").addEventListener("input", event => {
  searchTerm = event.target.value.trim().toLowerCase();
  renderProducts();
});
$("#openCart").addEventListener("click", openCart);
$("#closeCart").addEventListener("click", closeCart);
$("#overlay").addEventListener("click", closeCart);
$("#checkoutButton").addEventListener("click", () => {
  if (!cart.length) return;
  closeCart();
  $("#checkoutModal").classList.add("visible");
  document.body.classList.add("no-scroll");
});
function closeCheckout() {
  $("#checkoutModal").classList.remove("visible");
  document.body.classList.remove("no-scroll");
}
$("#closeCheckout").addEventListener("click", closeCheckout);
$("#checkoutModal").addEventListener("click", event => {
  if (event.target === $("#checkoutModal")) closeCheckout();
});
$("#checkoutForm").addEventListener("submit", event => {
  event.preventDefault();
  const data = new FormData(event.currentTarget);
  const lines = cart.map(item => `• ${item.name} x ${item.qty} — ${money(item.price * item.qty)}`).join("\n");
  const message = [
    "Hello NOOR! I would like to place a Cash on Delivery order.",
    "",
    lines,
    "",
    `Subtotal: ${money(cartTotal())}`,
    `Name: ${data.get("name")}`,
    `Phone: ${data.get("phone")}`,
    `City: ${data.get("city")}`,
    `Address: ${data.get("address")}`,
    "",
    "Please confirm delivery charges and availability."
  ].join("\n");
  if (WHATSAPP_NUMBER === "923001234567") {
    $("#checkoutMessage").textContent = "Demo mode: first edit app.js and replace WHATSAPP_NUMBER with your own WhatsApp number, then try again.";
    return;
  }
  window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`, "_blank", "noopener,noreferrer");
});
$("#newsletterForm").addEventListener("submit", event => {
  event.preventDefault();
  $("#newsletterMessage").textContent = "Thanks! This demo form does not store email addresses yet.";
  $("#newsletterEmail").value = "";
});
$("#year").textContent = new Date().getFullYear();
renderProducts();
renderCart();
